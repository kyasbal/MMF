﻿using MMDFileParser;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMDFileParser.MotionParser
{
    public class LightFrameList
    {
        internal static LightFrameList getLightFrameList(Stream fs)
        {
            LightFrameList lfl = new LightFrameList();
            try
            {
                lfl.LightCount = ParserHelper.getDWORD(fs);
            }
            catch (EndOfStreamException eof)
            {
                lfl.LightCount = 0;
                return lfl;
            }
            for (int i = 0; i < lfl.LightCount; i++) lfl.LightFrames.Add(LightFrameData.getLightFrame(fs));
            return lfl;
        }

        public uint LightCount;

        public List<LightFrameData> LightFrames = new List<LightFrameData>();
    }
}
