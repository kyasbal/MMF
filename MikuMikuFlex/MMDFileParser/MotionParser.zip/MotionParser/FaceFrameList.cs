﻿using MMDFileParser;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMDFileParser.MotionParser
{
    public class FaceFrameList
    {
        internal static FaceFrameList getFraceFrameList(Stream fs)
        {
            FaceFrameList list = new FaceFrameList();
            try
            {
                list.FaceFrameListCount = ParserHelper.getDWORD(fs);
            }catch(EndOfStreamException eof)
            {
                list.FaceFrameListCount = 0;
                return list;
            }
            for (int i = 0; i < list.FaceFrameListCount; i++) list.FaceFrames.Add(FaceFrameData.getFaceFrame(fs));
            return list;
        }
        public uint FaceFrameListCount;

        public List<FaceFrameData> FaceFrames = new List<FaceFrameData>();
    }
}
