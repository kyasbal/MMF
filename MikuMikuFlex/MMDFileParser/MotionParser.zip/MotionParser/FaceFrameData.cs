﻿using MMDFileParser;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMDFileParser.MotionParser
{
    public class FaceFrameData:IComparer<FaceFrameData>
    {
        internal static FaceFrameData getFaceFrame(Stream fs)
        {
            FaceFrameData ff = new FaceFrameData();
            ff.Name = ParserHelper.getShift_JISString(fs, 15);
            ff.FrameNumber = ParserHelper.getDWORD(fs);
            ff.FaceValue = ParserHelper.getFloat(fs);
            return ff;
        }

        public String Name;

        public uint FrameNumber;

        public float FaceValue;

        public int Compare(FaceFrameData x, FaceFrameData y)
        {
            var X =x; var Y = y;
            return (int)X.FrameNumber - (int)Y.FrameNumber;
        }
    }
}
